# Restaurant QR Menu

Красивое QR-меню в стиле современных ресторанных меню: публичная страница меню + простая админ-панель.

## Возможности

- Разделы меню: добавление, редактирование, удаление, скрытие.
- Позиции меню: название, описание, цена, старая цена, вес/объем, фото, бейджи, аллергены.
- Метки: популярное, новинка.
- Сортировка через поле `Позиция`.
- Настройки ресторана: название, подзаголовок, валюта, цвета, обложка.
- SQLite база без сложной настройки.

## Запуск локально

```bash
npm install
cp .env.example .env
npm start
```

Меню: `http://localhost:3000/`
Админка: `http://localhost:3000/admin`

Логин/пароль берутся из `.env`:

```env
ADMIN_USERNAME=admin
ADMIN_PASSWORD=change_me_123
```

После первого запуска база `menu.db` создастся автоматически.

## Деплой на VPS

```bash
git clone <repo>
cd restaurant-qr-menu
npm install
cp .env.example .env
nano .env
npm start
```

Для постоянного запуска лучше использовать PM2:

```bash
npm i -g pm2
pm2 start server.js --name restaurant-menu
pm2 save
pm2 startup
```

Для домена поставь Nginx reverse proxy на порт `3000`.
