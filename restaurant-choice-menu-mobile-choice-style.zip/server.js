const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

const uploadDir = path.join(__dirname, 'public/uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    if (!file.mimetype.startsWith('image/')) return cb(new Error('Only images are allowed'));
    cb(null, true);
  }
});

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 14 }
}));
app.use(flash());

function settings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}

function requireAdmin(req, res, next) {
  if (!req.session.adminId) return res.redirect('/admin/login');
  next();
}

app.use((req, res, next) => {
  res.locals.flash = req.flash();
  res.locals.currentPath = req.path;
  next();
});

app.get('/', (req, res) => {
  const s = settings();
  const categories = db.prepare('SELECT * FROM categories WHERE is_active = 1 ORDER BY position, id').all();
  const items = db.prepare('SELECT * FROM items WHERE is_active = 1 ORDER BY position, id').all();
  const grouped = categories.map(c => ({ ...c, items: items.filter(i => i.category_id === c.id) }));
  res.render('menu', { settings: s, categories: grouped });
});

app.get('/admin/login', (req, res) => res.render('login'));
app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    req.flash('error', 'Неверный логин или пароль');
    return res.redirect('/admin/login');
  }
  req.session.adminId = admin.id;
  res.redirect('/admin');
});
app.post('/admin/logout', (req, res) => req.session.destroy(() => res.redirect('/admin/login')));

app.get('/admin', requireAdmin, (req, res) => {
  const s = settings();
  const categories = db.prepare('SELECT * FROM categories ORDER BY position, id').all();
  const items = db.prepare(`SELECT items.*, categories.title as category_title FROM items
    LEFT JOIN categories ON categories.id = items.category_id
    ORDER BY categories.position, items.position, items.id`).all();
  res.render('admin', { settings: s, categories, items });
});

app.post('/admin/settings', requireAdmin, upload.single('cover_image'), (req, res) => {
  const allowed = ['restaurant_name', 'restaurant_subtitle', 'currency', 'theme_color', 'accent_color'];
  const stmt = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  allowed.forEach(k => stmt.run(k, req.body[k] || ''));
  if (req.file) stmt.run('cover_image', `/public/uploads/${req.file.filename}`);
  req.flash('success', 'Настройки сохранены');
  res.redirect('/admin');
});

app.post('/admin/categories', requireAdmin, (req, res) => {
  const { title, description, position, is_active } = req.body;
  db.prepare('INSERT INTO categories (title, description, position, is_active) VALUES (?, ?, ?, ?)')
    .run(title, description || '', Number(position || 0), is_active ? 1 : 0);
  req.flash('success', 'Раздел добавлен');
  res.redirect('/admin');
});

app.post('/admin/categories/:id', requireAdmin, (req, res) => {
  const { title, description, position, is_active } = req.body;
  db.prepare('UPDATE categories SET title=?, description=?, position=?, is_active=? WHERE id=?')
    .run(title, description || '', Number(position || 0), is_active ? 1 : 0, req.params.id);
  req.flash('success', 'Раздел обновлен');
  res.redirect('/admin');
});

app.post('/admin/categories/:id/delete', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM categories WHERE id=?').run(req.params.id);
  req.flash('success', 'Раздел удален');
  res.redirect('/admin');
});

app.post('/admin/items', requireAdmin, upload.single('image'), (req, res) => {
  const image = req.file ? `/public/uploads/${req.file.filename}` : '';
  const { category_id, title, description, price, old_price, weight, badges, allergens, is_popular, is_new, is_active, position } = req.body;
  db.prepare(`INSERT INTO items
    (category_id, title, description, price, old_price, weight, image, badges, allergens, is_popular, is_new, is_active, position)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      category_id, title, description || '', Number(price || 0), old_price || null, weight || '', image,
      badges || '', allergens || '', is_popular ? 1 : 0, is_new ? 1 : 0, is_active ? 1 : 0, Number(position || 0)
    );
  req.flash('success', 'Позиция добавлена');
  res.redirect('/admin');
});

app.post('/admin/items/:id', requireAdmin, upload.single('image'), (req, res) => {
  const current = db.prepare('SELECT image FROM items WHERE id=?').get(req.params.id);
  const image = req.file ? `/public/uploads/${req.file.filename}` : current?.image || '';
  const { category_id, title, description, price, old_price, weight, badges, allergens, is_popular, is_new, is_active, position } = req.body;
  db.prepare(`UPDATE items SET category_id=?, title=?, description=?, price=?, old_price=?, weight=?, image=?, badges=?, allergens=?, is_popular=?, is_new=?, is_active=?, position=? WHERE id=?`).run(
    category_id, title, description || '', Number(price || 0), old_price || null, weight || '', image,
    badges || '', allergens || '', is_popular ? 1 : 0, is_new ? 1 : 0, is_active ? 1 : 0, Number(position || 0), req.params.id
  );
  req.flash('success', 'Позиция обновлена');
  res.redirect('/admin');
});

app.post('/admin/items/:id/delete', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM items WHERE id=?').run(req.params.id);
  req.flash('success', 'Позиция удалена');
  res.redirect('/admin');
});

app.listen(PORT, () => console.log(`Menu site running: http://localhost:${PORT}`));
